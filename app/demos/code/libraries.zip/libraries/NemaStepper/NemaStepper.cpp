/*
	
	NemaStepper library.
	This library allows you to manage an unlimited number of Nema at the same time
	To start using the library,
	connect the motor to the Arduino using four digital pins.

	Motor connecting:
	The sequence of control signals for 4 control wires is as follows:
		Step C0 C1 C2 C3
		  1  1  0  1  0
		  2  0  1  1  0
		  3  0  1  0  1
		  4  1  0  0  1

	Then import the library in your code.
	Now declare your motor using, for example, this design (the designer supports the starting settings for the motor, such as: four pins, to which the motor is connected, the number of steps per revolution(most nema - 200):, the starting speed and a value indicating whether the motor brakes):
	
	NemaStepper Stepper1(2, 3, 4, 5, 200, 10, false);
	
	Next in the main cycle or timer (for example, you can use the library Timer) You must call your motor method Step():
	For example, in main loop:
	void Update(){
		Stepper1.Step();
	}
	in timer loop:
	void TimerTick(){
		Stepper1.Step();
	}

	To set the motor rotation, use the SetStepCount method, it takes positive or negative values:
	
	Stepper1.SetStepCount(100500);

	Or

	Stepper1.SetStepCount(-100500);
	
	The library also supports such methods as: SetSpeed() - set speed: 'most Nema - 60 'This method don't support negative values.
	
	Stepper1.SetSpeed(60)
	
	and SetBrakes() - set whether the motor will stop when tipping motion. 'When brakes enabled, the drivers can be a barbecue

	You can find some examples in "examples" folder.
	Licansed by MIT:
		Permission is hereby granted, free of charge, to any person obtaining
		a copy of this software and associated documentation files (the
		"Software"), to deal in the Software without restriction, including
		without limitation the rights to use, copy, modify, merge, publish,
		distribute, sublicense, and/or sell copies of the Software, and to
		permit persons to whom the Software is furnished to do so, subject to
		the following conditions:
 
		The above copyright notice and this permission notice shall be included
		in all copies or substantial portions of the Software.
 
		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
		EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
		MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
		IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
		CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
		TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
		SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
	Developed and writen by anunknowstudio, this library based on BobotStepper.
*/
#include "Arduino.h"
#include "NemaStepper.h"
    NemaStepper::NemaStepper(int mpin1, int mpin2, int mpin3, int mpin4, int stepsperrevolution, int startspeed, bool isstop){ //Constructor, MotorPin1,2,3,4, Steps per revolution, motor start speed, brakes
      _stepdelay = 60L * 1000L * 1000L / stepsperrevolution / startspeed / 1000; //Calculating motor speed
      _stepsperrev = stepsperrevolution; //Setting private variable _stepsperrev to parameter stepsperrevolution
      pinMode(mpin1, OUTPUT); //Configurate pins
      pinMode(mpin2, OUTPUT);
      pinMode(mpin3, OUTPUT);
      pinMode(mpin4, OUTPUT);
      pin1 = mpin1; //Setting local variables
      pin2 = mpin2;
      pin3 = mpin3;
      pin4 = mpin4;
      _stop = isstop; //set loacal variable _stop (brakes) to input parameter isstop
    }
    void NemaStepper::SetStepCount(int StepCount) { //Initaliaze rotation with steps count
      _stepcount = StepCount; //Setting local variable
    }
    void NemaStepper::Step() { //Try to onestep
      if ((millis() - _laststeptime) > _stepdelay) { //Delay
        if (_stepcount == 0) {
          if (_stop != true) { //Disable brakes
            digitalWrite(pin1, LOW);
            digitalWrite(pin2, LOW);
            digitalWrite(pin3, LOW);
            digitalWrite(pin4, LOW);
          }
        }
        if (_stepcount < 0) { //Calculating step number
          _stepcount++;
          _currentstep--;
          if (_currentstep == -1) {
            _currentstep = 3;
          }
          StepOneStep(_currentstep); //Do step
        } else if (_stepcount > 0) {
          _stepcount--;
          _currentstep++;
          if (_currentstep == 4) {
            _currentstep = 0;
          }
          StepOneStep(_currentstep); //Do step
        }
        steps = _stepcount;

        _laststeptime = millis(); //Set last time to millis.
      }
    }
    void NemaStepper::SetSpeed(int speed) { //Set motor speed
      _stepdelay = 60L * 1000L * 1000L / _stepsperrev / speed / 1000; //Calculating motor speed
    }
    void NemaStepper::SetBrakes(bool brakes) { //Set brakes
      _stop = brakes;
    }
    void NemaStepper::StepOneStep(int thisStep) { //Step one step with step number
      switch (thisStep) {
        case 0:  // 1010
          digitalWrite(pin1, HIGH);
          digitalWrite(pin2, HIGH);
          digitalWrite(pin3, LOW);
          digitalWrite(pin4, LOW);
          break;
        case 1:  // 0110
          digitalWrite(pin1, LOW);
          digitalWrite(pin2, HIGH);
          digitalWrite(pin3, HIGH);
          digitalWrite(pin4, LOW);
          break;
        case 2:  //0101
          digitalWrite(pin1, LOW);
          digitalWrite(pin2, LOW);
          digitalWrite(pin3, HIGH);
          digitalWrite(pin4, HIGH);
          break;
        case 3:  //1001
          digitalWrite(pin1, HIGH);
          digitalWrite(pin2, LOW);
          digitalWrite(pin3, LOW);
          digitalWrite(pin4, HIGH);
          break;
      }

    }