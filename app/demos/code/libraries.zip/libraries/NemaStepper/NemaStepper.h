/*
	NemaStepper library.
	This library allows you to manage an unlimited number of Nema at the same time
	To start using the library,
	connect the motor to the Arduino using four digital pins.

	Motor connecting:
	The sequence of control signals for 4 control wires is as follows:
		Step C0 C1 C2 C3
		  1  1  0  1  0
		  2  0  1  1  0
		  3  0  1  0  1
		  4  1  0  0  1

	Then import the library in your code.
	Now declare your motor using, for example, this design (the designer supports the starting settings for the motor, such as: four pins, to which the motor is connected, the number of steps per revolution(most nema - 200):, the starting speed and a value indicating whether the motor brakes):
	
	NemaStepper Stepper1(2, 3, 4, 5, 200, 10, false);
	
	Next in the main cycle or timer (for example, you can use the library Timer) You must call your motor method Step():
	For example, in main loop:
	void Update(){
		Stepper1.Step();
	}
	in timer loop:
	void TimerTick(){
		Stepper1.Step();
	}

	To set the motor rotation, use the SetStepCount method, it takes positive or negative values:
	
	Stepper1.SetStepCount(100500);

	Or

	Stepper1.SetStepCount(-100500);
	
	The library also supports such methods as: SetSpeed() - set speed: 'most Nema - 60 'This method don't support negative values.
	
	Stepper1.SetSpeed(60)
	
	and SetBrakes() - set whether the motor will stop when tipping motion. 'When brakes enabled, the drivers can be a barbecue

	You can find some examples in "examples" folder.
	Licansed by MIT:
		Permission is hereby granted, free of charge, to any person obtaining
		a copy of this software and associated documentation files (the
		"Software"), to deal in the Software without restriction, including
		without limitation the rights to use, copy, modify, merge, publish,
		distribute, sublicense, and/or sell copies of the Software, and to
		permit persons to whom the Software is furnished to do so, subject to
		the following conditions:
 
		The above copyright notice and this permission notice shall be included
		in all copies or substantial portions of the Software.
 
		THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
		EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
		MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
		IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
		CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
		TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
		SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
	Developed and writen by anunknowstudio, this library based on BobotStepper.
*/
// ensure this library description is only included once
#ifndef NemaStepper_h
#define NemaStepper_h

class NemaStepper {
  public:
    int steps;
    NemaStepper(int mpin1, int mpin2, int mpin3, int mpin4, int stepsperrevolution, int startspeed, bool isstop);
    void SetStepCount(int StepCount);
    void Step();
    void SetSpeed(int speed);
    void SetBrakes(bool brakes);
  private:
    int pin1;
    int pin2;
    int pin3;
    int pin4;
    int _stepsperrev;
    int _stepcount;
    int _stepdelay;
    unsigned long _laststeptime;
    int _currentstep;
    bool _stop;
    void StepOneStep(int thisStep);
};

#endif

